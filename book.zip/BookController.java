package com.ezen.spring.board.teampro.book;

import java.util.*;  

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;


import com.github.pagehelper.PageInfo;


@Controller
@RequestMapping("/book")
public class BookController
{
	@Autowired
	private BookSvc svc;
	
	
	@Autowired
	@Qualifier("bookdao")
	private BookDAO bookDAO;
	
	
	@GetMapping("/")
	public String index()
	{
		return "book/index";	
	}

	@GetMapping("/cart")
	public String cart()
	{
		return "book/cart";
	}
	
	@GetMapping("/add")
	public String add()
	{
		return "book/addform";
	}
	
	@GetMapping("/animal")
	public String animal()
	{
		return "book/animal";
	}
	
	@GetMapping("/princess")
	public String princess()
	{
		return "book/princess";
	}
	
	@GetMapping("/prince")
	public String prince()
	{
		return "book/prince";
	}
	
	@GetMapping("/korea")
	public String korea()
	{
		return "book/korea";
	}
	
	
	@GetMapping("/list/page/{pn}")
	public String list(@PathVariable("pn") int pageNum,
	                   @RequestParam(value = "category", required = false) String category,
	                   @RequestParam(value = "keyword", required = false) String keyword, Model model) {
	    PageInfo<Map> pageInfo = null;
	    if (category != null) {
	        pageInfo = bookDAO.search(category, keyword, pageNum);
	        model.addAttribute("category", category);
	        model.addAttribute("keyword", keyword);
	    } else {
	        pageInfo = bookDAO.getallbook(pageNum);
	    }
	    model.addAttribute("pageInfo", pageInfo);

	    return "book/blist";
	}


	@GetMapping("/list/page/2")
	public String list2() 
	{	
		return "book/blist2";
	}
	
	
	@GetMapping("/list/page/3")
	public String list3() 
	{
		return "book/blist3";
	}
	
	@GetMapping("/list/page/4")
	public String list4() 
	{
		return "book/blist4";
	}
	
	@GetMapping("/edit/{num}")
	public String edit(Model model,@PathVariable int num)
	{
		Book book = svc.getBookByNum(num);
		model.addAttribute("list",svc.getBook(num));
		return "book/edit";
	}

	@PostMapping("/update/{num}")
	@ResponseBody
	public Map<String, Object> update(@PathVariable int num, @RequestBody Book book) {
	    // num 값과 bookVO를 이용하여 데이터베이스에서 도서 정보를 수정하는 로직을 구현합니다.
	    // bookDAO.updateBook 메소드를 예시로 사용합니다. 이는 데이터베이스에 도서 정보를 업데이트하는 메소드라고 가정합니다.

	    // 먼저, 수정할 도서의 기존 정보를 가져옵니다.
	    Book existingBook = bookDAO.getBookById(num);
	    if (existingBook == null) {
	        // 기존 도서가 없는 경우, 수정 실패로 응답합니다.
	        Map<String, Object> response = new HashMap<>();
	        response.put("updated", false);
	        response.put("message", "해당 도서를 찾을 수 없습니다.");
	        return response;
	    }

	    // 클라이언트에서 전달한 bookVO 객체의 정보를 기존 도서 정보에 병합합니다.
	    existingBook.setPrice(book.getPrice());

	    // 데이터베이스에 수정된 도서 정보를 업데이트합니다.
	    boolean updateSuccess = bookDAO.updateBook(existingBook);

	    // 처리 결과를 클라이언트에게 응답합니다.
	    Map<String, Object> response = new HashMap<>();
	    response.put("updated", updateSuccess);
	    response.put("message", updateSuccess ? "도서 정보 수정 성공" : "도서 정보 수정 실패");
	    return response;
	}
	
	@PostMapping("/delete/{num}")
	@ResponseBody
	public Map<String, Object> deleteBook(@PathVariable int num) {
	    // 먼저, 삭제할 도서의 기존 정보를 가져옵니다.
	    Book existingBook = bookDAO.getBookById(num);
	    if (existingBook == null) {
	        // 기존 도서가 없는 경우, 삭제 실패로 응답합니다.
	        Map<String, Object> response = new HashMap<>();
	        response.put("deleted", false);
	        response.put("message", "해당 도서를 찾을 수 없습니다.");
	        return response;
	    }

	    // 데이터베이스에서 해당 도서 정보를 삭제합니다.
	    boolean deleteSuccess = bookDAO.deleteBook(num);

	    // 처리 결과를 클라이언트에게 응답합니다.
	    Map<String, Object> response = new HashMap<>();
	    response.put("deleted", deleteSuccess);
	    response.put("message", deleteSuccess ? "도서 정보 삭제 성공" : "도서 정보 삭제 실패");
	    System.out.println("response결과"+response);
	    return response;
	}


	
	@GetMapping("/detail/{num}")
	public String detail(@PathVariable int num ,Model model)
	{
		Book book = svc.getBookByNum(num);
		model.addAttribute("list",svc.getBook(num));
		return "book/detail";
	}
	
	
	   @PostMapping("/add")
	   @ResponseBody
	   public Map<String, Object> addBook(Model model,MultipartFile image, String bname, String author, String publisher,String pdate,String price) 
	   {
	        // 여기서부터는 전달받은 정보를 활용하여 도서 정보를 저장하는 로직을 구현합니다.
	        // 이 예시에서는 간단히 도서 정보를 출력하기만 하겠습니다.

	        System.out.println("도서명: " + bname);
	        System.out.println("가격:" + price);

	        // 이미지 파일 업로드를 원하면 아래와 같이 처리할 수 있습니다.
	        if (image != null && !image.isEmpty()) {
	            // 여기서 이미지를 저장하거나 다른 처리를 수행합니다.
	            System.out.println("이미지 파일 업로드 완료: " + image.getOriginalFilename());
	        }
	        Book book = new Book();
	        model.addAttribute("book",book);
	        model.addAttribute("price",price);
	        model.addAttribute("title",bname);
	    
	        // 처리 결과를 클라이언트에게 응답합니다.
	        Map<String, Object> response = new HashMap<>();
	        response.put("added", true);
	        response.put("message", "도서 정보 저장 성공");
	        return response;
	    }
	
	/*
	@GetMapping("/book/list/page/{pn}")
	public String getList(@PathVariable int pn, 
							@RequestParam(value="category", required=false) String category,
							@RequestParam(value="keyword", required=false) String keyword,
							Model model)
	{
		PageInfo<Map> pageInfo = null;
		if(category!=null) { //검색결과 목록
			pageInfo = bookDAO.search(category, keyword,pn);
			model.addAttribute("category", category);
			model.addAttribute("keyword", keyword);
		}else {  //검색 아닌 일반 목록
			pageInfo = bookDAO.getList(pn);
		}
		model.addAttribute("pageInfo", pageInfo);
		return "book/index";
	}
	*/
}
