package com.ezen.spring.board.teampro.book;

import java.sql.Connection; 
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import jakarta.persistence.EntityManager;
import jakarta.persistence.PersistenceContext;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;


@Repository("bookdao")
@Slf4j
public class BookDAO {
	
	private Map<Integer, Book> bookMap = new HashMap<>();
	
	@PersistenceContext
    private EntityManager entityManager;
	
	@Autowired
	private BookMapper bookMapper;
	
	private Connection rs;
	private Object pstmt;
	private Object conn;

	private Connection getConn() {
	    Connection conn = null;
	    String url = "jdbc:mysql://localhost:3306/test?characterEncoding=UTF-8&serverTimezone=UTC&SSL=false";
	    String username = "root";
	    String password = "ezenac";

	    try {
	        Class.forName("com.mysql.jdbc.Driver");
	        conn = DriverManager.getConnection(url, username, password);
	    } catch (Exception ex) {
	        ex.printStackTrace();
	    }
	    return conn;
	}

	
	
	public List<Book> getBook(int num) {
	    String sql = "SELECT * FROM book WHERE num = ?";
	    List<Book> bookList = new ArrayList<>();
	    PreparedStatement pstmt = null;
	    ResultSet rs = null;

	    Connection conn = getConn();
	    try {
	        pstmt = conn.prepareStatement(sql);
	        pstmt.setInt(1, num);
	        rs = pstmt.executeQuery();

	        while (rs.next()) {
	            String bname = rs.getString("bname");
	            String publisher = rs.getString("publisher");
	            String author = rs.getString("author");
	            String price = rs.getString("price");
	            String pdate = rs.getString("pdate");
	            String img = rs.getString("img");
	            String introduce = rs.getString("introduce");

	            Book book = new Book();
	            book.setNum(num);
	            book.setBname(bname);
	            book.setPublisher(publisher);
	            book.setAuthor(author);
	            book.setPrice(price);
	            book.setPdate(pdate);
	            book.setImg(img);
	            book.setIntroduce(introduce);
	            
	            bookList.add(book);
	        }
	    } catch (Exception ex) {
	        ex.printStackTrace();
	    } finally {
	        closeAll();
	    }
	    return bookList;
	}
	
	public List<Book> addBook(int num) {
		String sql = "INSERT INTO blist(bname,price,img) VALUES ?,?,?";
		List<Book> bookList = new ArrayList<>();
		PreparedStatement pstmt = null;
		ResultSet rs = null;
		
		Connection conn = getConn();
		try {
			pstmt = conn.prepareStatement(sql);
			pstmt.setInt(1, num);
			rs = pstmt.executeQuery();
			
			while (rs.next()) {
				String bname = rs.getString("bname");
				String price = rs.getString("price");
				String img = rs.getString("img");
				
				Book book = new Book();
				book.setBname(bname);
				book.setPrice(price);
				book.setImg(img);
				
				
				bookList.add(book);
			}
		} catch (Exception ex) {
			ex.printStackTrace();
		} finally {
			closeAll();
		}
		return bookList;
	}

	private void closeAll() 
	{
	    try {
	        if (rs != null) rs.close();
			if(pstmt!=null) ((Connection) pstmt).close();
	        if(conn!=null) ((Connection) conn).close();
	    } catch (Exception ex) {
	        ex.printStackTrace();
	    }
	}

	public Book getBookByNum(int num) {
	    List<Book> bookList = getBook(num);
	    for (Book book : bookList) {
	        if (book.getNum() == num) {
	            return book;
	        }
	    }
	    return null;
}



	public int getBookCount() {
	    String sql = "SELECT COUNT(*) FROM book";
	    int count = 0;

	    try (Connection conn = getConn();
	         PreparedStatement pstmt = conn.prepareStatement(sql);
	         ResultSet rs = pstmt.executeQuery()) {

	        if (rs.next()) {
	            count = rs.getInt(1);
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    return count;
	}

	public List<Book> getBooksByPage(int page, int pageSize) {
	    String sql = "SELECT * FROM book LIMIT ?, ?";
	    int offset = (page - 1) * pageSize;

	    List<Book> bookList = new ArrayList<>();

	    try (Connection conn = getConn();
	         PreparedStatement pstmt = conn.prepareStatement(sql)) {

	        pstmt.setInt(1, offset);
	        pstmt.setInt(2, pageSize);

	        try (ResultSet rs = pstmt.executeQuery()) {
	            while (rs.next()) {
	                Book book = new Book();
	                // 도서 정보를 ResultSet에서 읽어와서 Book 객체에 설정
	                bookList.add(book);
	            }
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return bookList;
	}



	public PageInfo<Map> search(String category,String keyword, int pageNum)
	{
		PageHelper.startPage(pageNum,5);
		Book vo = new Book();
		if(category.equals("bname")) {vo.setBname(keyword);}
		else if(category.equals("publisher")) {vo.setPublisher(keyword);}
		else if(category.equals("author")) {vo.setAuthor(keyword);}
		
		PageInfo<Map> pageInfo = new PageInfo<>(bookMapper.search(vo));
		
		
		return pageInfo;
		
	}



	public PageInfo<Map> getallbook(int pageNum) {
		PageHelper.startPage(pageNum,4);
		PageInfo<Map> pageInfo = new PageInfo<> (bookMapper.getallbook());
		
		return pageInfo;
		
	}



	   @Transactional
	    public boolean updateBook(Book existingBook) {
	        try {
				// 주어진 id에 해당하는 도서가 데이터베이스에 있는지 확인합니다.
	            Book bookToUpdate = entityManager.find(Book.class, existingBook.getPrice());
	            if (bookToUpdate == null) {
	                // 주어진 id에 해당하는 도서가 데이터베이스에 없을 경우, 수정 실패를 반환합니다.
	                return false;
	            }

	            // 새로운 도서 정보로 기존 도서 정보를 업데이트합니다.
	            bookToUpdate.setPrice(existingBook.getPrice());

	            // 수정된 도서 정보를 데이터베이스에 저장합니다.
	            entityManager.merge(bookToUpdate);
	            return true;
	        } catch (Exception e) {
	            // 도서 정보 업데이트 과정에서 발생할 수 있는 예외를 처리합니다.
	            e.printStackTrace();
	            return false;
	        }
	    }



	public Book getBookById(int num) {
		
		return bookMap.get(num);
	}

	 public boolean deleteBook(int num) {
	        // SQL 쿼리
	        String sql = "DELETE FROM book WHERE num= ?";

	        try (Connection connection = getConn();
	             PreparedStatement statement = connection.prepareStatement(sql)) {

	            // PreparedStatement에 파라미터 값 설정
	            statement.setInt(1, num);

	            // 쿼리 실행
	            int rowsDeleted = statement.executeUpdate();

	            // 삭제된 행이 1개 이상일 경우 true 반환
	            return rowsDeleted > 0;

	        } catch (Exception e) {
	            e.printStackTrace();
	            // 여기서 예외를 처리하거나 적절한 방법으로 반환할 수도 있습니다.
	        }

	        // 삭제 실패 시 false 반환
	        return false;
	    }


}

/*
	public PageInfo<Map> search(String category, String keyword, int pageNum) 
	{
		PageHelper.startPage(pageNum, 10);
		
		Book key = new Book();
		if(category.equals("bname")) key.setBname(keyword);
		else if(category.equals("author")) key.setAuthor(keyword);
		else if(category.equals("introduce")) key.setIntroduce(keyword);
		
	
		PageInfo<Map> pageInfo = new PageInfo<>(bookMapper.searchByBook(key));
		return pageInfo;
	}



	public PageInfo<Map> getList(int pageNum) 
	{	
		PageHelper.startPage(pageNum, 10);
		PageInfo<Map> pageInfo = new PageInfo<>(bookMapper.getList());
		return pageInfo;
	}



}
	/*
	public Book getBookByNum(int num) {
		List<Book> bookList = getList();
	    for (Book book : bookList) {
	        if (book.getNum() == num) {
	            return book;
	        }
	}
		return null;
}
*/
