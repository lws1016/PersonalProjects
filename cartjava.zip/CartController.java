package com.ezen.spring.board.teampro.cart;

import java.util.*;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Conditional;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.ezen.spring.board.teampro.login.MemberVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;
import jakarta.websocket.server.PathParam;

@Controller
@RequestMapping("/fairy")
@SessionAttributes("userid")
public class CartController {
	@Autowired
	@Qualifier("cartdao")
	CartDAO dao;
	
	@Autowired
	@Qualifier("VO")
	BookVO vo;
	@GetMapping("/cart/index")
	public ModelAndView index()
	{
		 ModelAndView modelAndView = new ModelAndView("cart/index");
		return modelAndView;
	}
	@GetMapping("/book/{bnum}")
	public ModelAndView getbook(@PathVariable int bnum,Model model)
	{
		List<BookVO> blist = new ArrayList<>();
		blist = dao.getbook(bnum);
		 ModelAndView modelAndView = new ModelAndView("cart/detail");
		 model.addAttribute("book", blist);
		return modelAndView;
	}

	@GetMapping("/cart/detail")
	public ModelAndView getcart(Model model,int bnum)
	{
		List<BookVO> blist = new ArrayList<>();
		blist = dao.getbook(bnum);
		 ModelAndView modelAndView = new ModelAndView("cart/detail");
		 model.addAttribute("book", blist);
		return modelAndView;
	}
//==============================================여기서부터 카트추가=================================================================================	
//==============================================여기서부터 카트추가=================================================================================		
	@PostMapping("/cart/add/{bnum}")
	@ResponseBody
	public Map<String,Boolean> getcartadddd(@PathVariable int bnum,@RequestParam int quantity,@RequestParam String bname,@SessionAttribute(name = "userid", required = false)String userid)
	{
		Map<String,Boolean> map = new HashMap<>();
		if (userid != null) {
	        String id = userid;   
	        boolean added = dao.getcartadd(bname,quantity, id );
	        map.put("added", added);
		}else {
	        map.put("added", false);
	    }
		return map;
	}
	
	@GetMapping("/cart/list")
	public ModelAndView getlist(Model model,@SessionAttribute(name = "userid", required = false)String userid)
	{
		List<BookVO> blist = new ArrayList<>();
		blist = dao.getlist(userid);
		 ModelAndView modelAndView = new ModelAndView("cart/showCartjsp");
		 model.addAttribute("book", blist);
		return modelAndView;
	}
	
//==============================================장바구니에서 삭제로직=================================================================================		
//==============================================장바구니에서 삭제로직=================================================================================
	
	@PostMapping("/cart/delete")
	@ResponseBody
	public Map<String,Boolean> getdelete(@RequestParam(value="bname[]") List<String> bname,@SessionAttribute(name = "userid", required = false)String userid)
	{
	  Map<String,Boolean> map = new HashMap<>();
	  List<String> intlist = new ArrayList<>();
	  intlist = bname;
	  for(int i=0;i<intlist.size();i++) {
		  String snum=intlist.get(i);
		if (userid != null) {
			String id = userid; 
			map.put("deleted", dao.getdelete(snum));
		}else {
	        map.put("deleted", false);
	    	}
		}
	  return map;
	}
	
//==============================================결제창=================================================================================	
//==============================================결제창=================================================================================	
	
	@GetMapping("/cart/bey")
	public ModelAndView beycart() {
		ModelAndView modelAndView = new ModelAndView("cart/beycart");
		return modelAndView;
	}
	
	@PostMapping("/cart/bey")
	@ResponseBody
	public String beycart(@RequestParam(value = "bname[]") List<String> bname,HttpServletRequest request,
	                      @SessionAttribute(name = "userid", required = false) String userid) throws Exception {
	    HttpSession session = request.getSession();
	    List<BookVO> selectedBooks = new ArrayList<>();
	    for (String selectedbname : bname) {
	         selectedBooks.add(dao.getbeylist(selectedbname,userid));
	    }
	    session.setAttribute("selectedBooks", selectedBooks);
	    return "cart/beycart";
	}
	
//==============================================결제후 bougthbook테이블로 넘어감=================================================================================	
//==============================================결제후 bougthbook테이블로 넘어감=================================================================================
	
	@PostMapping("/cart/bought")
	@ResponseBody
	public Map<String,Object> bought(@RequestParam(value = "bname[]") List<String> bname,
										@RequestParam(value = "userid") String uid,
										@RequestParam(value = "quantity[]") List<Integer> quantity,
										@SessionAttribute(name = "userid", required = false) String userid) {
		 Map<String, Object> paramMap = new HashMap<>();
		  paramMap.put("uid", uid);
		  paramMap.put("bname", bname);
		  paramMap.put("quantity", quantity);
	    if (userid != null) {
	        for (int i=0;i<bname.size();i++) {   	
	            boolean bought = dao.getbought(bname.get(i), uid, quantity.get(i));
	            paramMap.put("bought", bought);
	            
	            if (!bought) {
	            	paramMap.put("bought", false);
	            }
	        }
	    }
	    return paramMap;
	}
//==============================================결제후 cart테이블삭제=================================================================================	
//==============================================결제후 cart테이블삭제=================================================================================	
	@PostMapping("/cart/remove")
	@ResponseBody
	public Map<String,Boolean> remove(@SessionAttribute(name = "userid", required = false) String userid){
		
		Map<String,Boolean> map = new HashMap<>();
		boolean remove = dao.getdeleteAll();
		map.put("remove",remove );
		return map;
		
	}




}
