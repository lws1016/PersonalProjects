package com.ezen.spring.board.teampro.cart;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

@Component("cartdao")
public class CartDAO {
	@Autowired
	@Qualifier("catmapper")
	public CartMapper CartMapper; 
	
	public List<BookVO> getbook(int bnum) {
		return CartMapper.getbook(bnum);
	}
	
	public boolean getcartadd(String bname,int quantity,String userid) {
		return CartMapper.getcart(bname,quantity,userid)>0;
	}
	
	public List<BookVO> getlist(String userid){
		return CartMapper.getlist(userid);
	}

	public boolean getdelete(String bname) {
		return CartMapper.getdelete(bname)>0;
	}
	
	public BookVO getbeylist(String bname,String userid){
		return CartMapper.getbeylist(bname,userid);
	}
	
	@Transactional
	public boolean getbought(String bname,String uid,int quantity){
		boolean bsave = CartMapper.boughtbook(bname,uid, quantity)>0;
		
		boolean delbook = CartMapper.getdelete(bname)>0;
		
		return bsave&&delbook;
	}
	
	public boolean getdeleteAll() {
		return CartMapper.getdeleteAll()>0;
	}
	
}
