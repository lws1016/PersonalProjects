package com.ezen.spring.board.teampro.cart;

import java.util.*;

import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Component;

@Component("catmapper")
@Mapper
public interface CartMapper {
	
	public List<BookVO> getbook(int bnum);
	
	public int getcart(String bname,int quantity,String userid);
	
	public List<BookVO> getlist(String userid);
	
	public int getdelete(String bname);

	public BookVO getbeylist(String bname,String userid);
	
	public int boughtbook(String bname,String uid,int quantity);
	
	public int getdeleteAll();
	
}
