package com.ezen.spring;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.*;
import jakarta.servlet.http.HttpServletRequest;

@Controller
public class IndexController 
{
	@Autowired//자동으로 new GuguSVC를 해달라는 말 그래서 변수만 선언해도 쉽게 가능함
	private GuguSVC guguSvc;
	
   @GetMapping("/")
   public String index() {
      return "index";  /*/WEB-INF/jsp/index.jsp */
   }

   
   @GetMapping("/multab")
   @ResponseBody
   public Map<String, List<String>> multab(@RequestParam("dan") int dan) 
   {
	   List<String> glist = guguSvc.getGugu(dan);
       Map<String, List<String>> madd = new HashMap<>();
       madd.put("gugu", glist);
      return madd;  /*/WEB-INF/jsp/index.jsp */
   }
 //===========================================================================  
   @GetMapping("/gugu")
   public String gugu(HttpServletRequest request) {
	   int dan = Integer.parseInt(request.getParameter("dan"));

	   List<String> glist = guguSvc.getGugu(dan);
	      request.setAttribute("glist", glist);
	      return "gugu";
	   }
//===========================================================================   
   @GetMapping("/gugu2")
   public String gugu2(@RequestParam("dan")int dan,
		   				HttpServletRequest request) 
   {
	   List<String> glist = guguSvc.getGugu(dan);
	      request.setAttribute("glist", glist);
	      return "gugu";
   }
//===========================================================================   
   @GetMapping("/gugu3")
   public String gugu3(@RequestParam("dan")int dan, Model model) //모델은 그냥 참조형변수만 선언하면 스프링이 알아서 객체를 넣어줌 디팬던스인댁션(DI=Dependency Injection)
   {
	    List<String> glist = guguSvc.getGugu(dan);
	      model.addAttribute("glist", glist);//request말고 스프링프레임워크에선 모델을 주로 씀
	      return "gugu";
	}
 //===========================================================================   
  @GetMapping("/gugu4/{dan}")
   public String gugu4(@PathVariable("dan")int dan, Model model)//gugu4/dan의 dan을 호출시 자동으로 입력되게 하는것 gugu4/5라고 하면 gugu4/dan=5라는 뜻임
   {
	    List<String> glist = guguSvc.getGugu(dan);
	      model.addAttribute("glist",glist);//request말고 스프링프레임워크에선 모델을 주로 씀
	      return "gugu";
	}
   //===========================================================================     
   @GetMapping({"/gugu5","/gugu5/{dan}"})//gugu4/5 <-PV가 없는 경우
   public String gugu5(@PathVariable("dan")Optional<Integer> opt, Model model)
   {
	   int dan = 2;
	   if(opt.isPresent()){//isPresent 값이 있으면 이라는 뜻
	   dan =opt.get();
	   }
		    List<String> glist = guguSvc.getGugu(dan);
	      model.addAttribute("glist", glist);//request말고 스프링프레임워크에선 모델을 주로 씀
	      return "gugu";
	}
   
  @GetMapping("/add")
   public String add(HttpServletRequest request) {
	   int a = Integer.parseInt(request.getParameter("a"));
	   int b = Integer.parseInt(request.getParameter("b"));
	   
	 
	   request.setAttribute("add", String.format("%d+%d=%d", a,b,a+b));
	      return "add";
   }
   @GetMapping("/add2/{num1}/{num2}")
   public String add2(@PathVariable("num1")int n1,@PathVariable("num2")int n2, Model model) {

	   int n3 = n1+n2;
	   model.addAttribute("add", String.format("%d+%d=%d", n1,n2,n3));
	      return "add";
   }
   
   @GetMapping("/xxx/{num1}/{num2}")
   @ResponseBody
   public Map<String,String> xxx(@PathVariable("num1")int n1,@PathVariable("num2")int n2) {

	   int n3 = n1*n2;
	   //model.addAttribute("add", String.format("%dx%d=%d", n1,n2,n3));
	   Map<String,String> madd = new HashMap<>();
	   madd.put("add", String.format("%dx%d=%d", n1,n2,n3));
	   return madd;
   }


}