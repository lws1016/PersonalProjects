package com.ezen.spring.board.teampro.book;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import com.ezen.spring.board.teampro.cart.BookVO;
import com.ezen.spring.board.teampro.login.MemberVO;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

@Component("bookdao")
public class BookDAO {

	
	@Autowired
	@Qualifier("bookmapper")
	private BookMapper bookmap;
	
	
	public boolean addbooks(Book bo) {
		boolean add = bookmap.addbook(bo)>0;
		return add;
	}
	
	public PageInfo<Map> getallbook(int pageNum) {
		PageHelper.startPage(pageNum,10);
		PageInfo<Map> pageInfo = new PageInfo<> (bookmap.getallbook());
		
		return pageInfo;
	}
	
	public PageInfo<Map> search(String category,String keyword, int pageNum)
	{
		PageHelper.startPage(pageNum,10);
		Book vo = new Book();
		if(category.equals("bname")) {vo.setBname(keyword);}
		else if(category.equals("publisher")) {vo.setPublisher(keyword);}
		else if(category.equals("author")) {vo.setAuthor(keyword);}
		
		PageInfo<Map> pageInfo = new PageInfo<>(bookmap.search(vo));
		
		
		return pageInfo;
		
	}
	public List<Book> catesearch(String cate)
	{
		List<Book> vo = bookmap.CateSearch(cate);
		return vo;
	}

	public Book getbook(int bnum) {
		return bookmap.getbook(bnum);
	}
	
	public boolean deletebook(int bnum){
		return bookmap.getdelete(bnum)>0;
	}
	
	   public List<Book> best()
	   {
	      List<Book> vo  = bookmap.best();
	      return vo;
	   }

	   public boolean updateBook(Book b)
	   {
	      return bookmap.updateBook(b) > 0;
	   }

	   public boolean addqna(QnAVO vo) {
		      
		      return bookmap.qnaadd(vo)>0;
		}
		   
		public List<Map> getqna1(int pnum){
		   List<Map> qlist = bookmap.getqnalist(pnum);
		   return qlist;
		}

		public MemberVO getmember(String userid) {
		      return bookmap.getMem(userid);
		   }

	
}
