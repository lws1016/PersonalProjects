package com.ezen.spring.board.teampro.login;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;

import com.ezen.spring.board.teampro.admin.AdminVO;
import com.ezen.spring.board.teampro.login.MemberVO;

@Repository("fairydao")
public class FairyDAO 
{
    //@Autowired
    //private MemberIO io; 
      
    @Autowired
    @Qualifier("fairyMem")
    private MemberVO memvo;
    
    @Autowired
    @Qualifier("fairyMapper")
    private FairyMapper fairyMapper;
	
	public boolean addJoin(MemberVO mem) 
	{
	    return fairyMapper.addfairyMem(mem)>0;
	}

	public boolean joinIdCheck(MemberVO mem) 
	{
		
		return fairyMapper.joinIdCheck(mem)>0;
	}

	public boolean joinEmailCheck(MemberVO mem) 
	{
		
		return fairyMapper.joinEmailCheck(mem)>0;
	}

	public boolean login(MemberVO mem) 
	{
	    return fairyMapper.loginCheck(mem)>0;
	}

	public MemberVO getJoinedMem(String userid) 
	{
		
		return fairyMapper.getJoinedMem(userid);
	}

	public List<AdminVO> getBought(String userid) 
	{
		
		return fairyMapper.getboughtbook(userid);
	}
		
	public boolean adminLogin(MemberVO mem)
	{
		 MemberVO member = fairyMapper.adminLoginCheck(mem);  
		 return member != null;
	}


	public boolean updatedMem(MemberVO mem)
	   {
	      
	      return fairyMapper.updatedMem(mem)>0;
	   }
	
	public List<MemberVO> getmemlist()
	   {
	      return fairyMapper.getMem();
	   }
	
	public boolean userExists(MemberVO mem)
	{
		return fairyMapper.userExists(mem)>0;
	}
	
	public boolean Escemp(int fnum) {
		
		return fairyMapper.empdel(fnum)>0;
	}
	

}
