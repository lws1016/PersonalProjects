package com.ezen.spring.empfile;

import java.util.*;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.ezen.spring.user.UserVO;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Controller 
@RequestMapping("/emp")
@SessionAttributes("userid")
public class EmpController {
	HttpServletRequest request; 
	HttpServletResponse response;
	
	public EmpController (HttpServletRequest request, HttpServletResponse response) {
		super();
		this.request = request;
		this.response = response;
		
	}
	@Autowired
	EmpSvc es;
	EmpVO vo;
	EmpIO io;
	@GetMapping("/")//get방식 요청
	public String index()
	{
		return "emp/index";
		
	}
	@GetMapping("/add")
	public String addForm()
	{
		return "emp/addForm";
	}
	@PostMapping("/add")
	@ResponseBody
	public Map<String, Boolean> add(@SessionAttribute(name = "userid", required = false) UserVO uid, EmpVO vo) {
	    Map<String, Boolean> map = new HashMap<>();
	    if (uid != null) {
	        String id = uid.getUid();
	        map.put("added", es.add(vo));
	    } else {
	        map.put("added", false);
	    }
	    return map;
	}
	@GetMapping("/list")
	public String list()
	{
		Map<String, List<EmpVO>> map = new HashMap<>();
		map.put("elist", es.list());
		return "emp/list";
	}
	
	@PostMapping("/search")
	public String search(Model model) {
	    String cat = request.getParameter("category");
	    String key = request.getParameter("key");
	    List<EmpVO> elist;
	    if (cat.equals("번호")) {
	        elist = es.searchbynum(Integer.parseInt(key));
	        System.out.println("번호" + elist);
	    } else if (cat.equals("이름")) {
	        elist = es.searchbyname(key);
	        System.out.println("이름" + elist);
	    } else {
	        elist = new ArrayList<>(); // 기본적으로 빈 리스트로 초기화
	    }

	    model.addAttribute("elist", elist);
	    return "emp/searchform";
	}
	
	@GetMapping("/detail/{empno}")
	public String dateil(@PathVariable int empno, Model model) {
	        vo = es.datailbynum(empno);
	    model.addAttribute("belist",vo);
	    return "emp/detail";
	}
	
	@GetMapping("/update/{empno}")
	public String update(@PathVariable int empno, Model model)
	{	
		
		vo = es.datailbynum(empno);
		model.addAttribute("updated", vo);
		return "emp/updateform";
	}
	@PostMapping("/updated")
	@ResponseBody
	public Map<String,Boolean> update(@SessionAttribute(name = "userid", required = false) UserVO uid)
	{	
		Map<String, Boolean> map = new HashMap<>();
		
		if (uid != null) {
	        String id = uid.getUid();
	        
	        map.put("updatedd", es.update(vo));
		}else {
	        map.put("updatedd", false);
	    }
		return map;
	}
	@PostMapping("/removed/{empno}")
	@ResponseBody
	public  Map<String,Boolean> remove(@PathVariable int empno, Model model,@SessionAttribute(name = "userid", required = false) UserVO uid)
	{	
		
		Map<String, Boolean> map = new HashMap<>();
		if (uid != null) {
	        String id = uid.getUid();
	        map.put("removed", es.remove(empno));
		}else {
	        map.put("removed", false);
	    }
		return map;
	}

}
