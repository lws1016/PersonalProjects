package com.ezen.spring.empfile;

import java.io.*;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class EmpIO {

	@Autowired
	static String fpath = "D:/test/emp.txt";
	public EmpIO() 
	{
		File f = new File(fpath);
		if(!f.exists()) {
			try {
				ObjectOutputStream oos = new ObjectOutputStream(
						new FileOutputStream(fpath));
				oos.writeObject(new ArrayList<EmpVO>());
				oos.close();
				System.out.println("emp.txt 파일 생성됨");
			} catch (Exception e) {
				System.err.println("emp.txt 파일생성 오류");
			}
		}
	}
	public boolean writeToFile(EmpVO emp) {
	    PrintWriter writer = null;
	    try {
	        writer = new PrintWriter(new FileWriter(fpath,true));
	        writer.println(emp.toString()); // 예시: EmpVO의 toString() 메서드를 호출하여 텍스트로 변환
	        return true;
	        
	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        if (writer != null) {
	            writer.close();
	        }
	    }
	    return false;
	}
	public List<EmpVO> readFromFile() {
	    BufferedReader reader = null;
	    List<EmpVO> blist = new ArrayList<>();
	    try {
	        reader = new BufferedReader(new FileReader(fpath));
	        String line;
	        while ((line = reader.readLine()) != null) {
	            // 텍스트를 파싱하여 EmpVO 객체로 변환
	            EmpVO emp = parseEmpVO(line);
	            if (emp != null) {
	                blist.add(emp);
	            }
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        if (reader != null) {
	            try {
	                reader.close();
	            } catch (IOException e) {
	                e.printStackTrace();
	            }
	        }
	    }
	    return blist;
	}

	private EmpVO parseEmpVO(String line) {
	    String[] fields = line.split(" "); // 공백으로 구분된 텍스트를 필드 배열로 분할
	    // 필드 배열로부터 EmpVO 객체 생성
	    if (fields.length == 4) {
	        try {
	            int empno = Integer.parseInt(fields[0]);
	            String ename = fields[1];
	            String hiredate = fields[2];
	            int sal = Integer.parseInt(fields[3]);

	            return new EmpVO(empno, ename, hiredate, sal);
	        } catch (NumberFormatException e) {
	            e.printStackTrace();
	        }
	    }

	    return null; // 파싱에 실패하면 null 반환
	}
	
	public boolean overwrite(List<EmpVO> list) {
	    PrintWriter writer = null;
	    try {
	        writer = new PrintWriter(new FileWriter(fpath));
	        for(EmpVO vo : list) {
	        writer.println(vo.toString()); // 예시: EmpVO의 toString() 메서드를 호출하여 텍스트로 변환
	        }
	        return true;
	        
	    } catch (Exception e) {
	        e.printStackTrace();
	    } finally {
	        if (writer != null) {
	            writer.close();
	        }
	    }
	    return false;
	}
	
	public EmpVO find(EmpVO vo)
	{
		List<EmpVO> list = readFromFile();
		if(list.contains(vo))
		{
			EmpVO found = list.get(list.indexOf(vo));
			return found;
		}
		return null;
	}
	

}
