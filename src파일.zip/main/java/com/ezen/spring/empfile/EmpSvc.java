package com.ezen.spring.empfile;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@Service
public class EmpSvc {
	@Autowired
	EmpIO io;
	EmpVO vo;
	HttpServletRequest request; 
	HttpServletResponse response;
	List<EmpVO> elist = new ArrayList<>();
	
	public EmpSvc(HttpServletRequest request, HttpServletResponse response) {
		super();
		this.request = request;
		this.response = response;
		
	}
	
	public boolean add(EmpVO vo) {
		
		io.writeToFile(vo);
		return true;
	}
	public List<EmpVO> list() 
	{
		elist = new EmpIO().readFromFile();
		request.setAttribute("elist", elist);
		return elist;
	}
	public List<EmpVO> searchbynum(int num) {
	    elist = new EmpIO().readFromFile();
	    EmpVO vo = new EmpVO();
	    vo.setEmpno(num);
	    List<EmpVO> resultList = new ArrayList<>();
	    for (EmpVO emp : elist) {
	        if (emp.getEmpno()==vo.getEmpno()) {
	            resultList.add(emp);
	        }
	    }
	    
	    return resultList;
	}

	public List<EmpVO> searchbyname(String name) {
	    elist = new EmpIO().readFromFile();
	    EmpVO vo = new EmpVO();
	    vo.setEname(name);
	    List<EmpVO> resultList = new ArrayList<>();
	    for (EmpVO emp : elist) {
	        if (emp.getEname().equals(vo.getEname())) {
	            resultList.add(emp);
	        }
	    }
	    return resultList;
	}
	
	public EmpVO datailbynum(int empno) {
		EmpVO vo = new EmpVO();
		vo.setEmpno(empno);
	    return io.find(vo);
	}

	public boolean update(EmpVO vo) {
		int sal = Integer.parseInt(request.getParameter("sal"));
		List<EmpVO> list = io.readFromFile();
	        if (list.contains(vo)) {
	            list.get(list.indexOf(vo)).setSal(sal);
	        }
	    io.overwrite(list);
	    return true;
	}
	
	public boolean remove(int empno) {
		 EmpVO vo = new EmpVO();
		  vo.setEmpno(empno);
		List<EmpVO> list = io.readFromFile();
	        if (list.contains(vo)) {
	            list.remove(list.get(list.indexOf(vo)));
	        }
	    io.overwrite(list);
	    return true;
	}
	

//============================================================================================	
	public EmpVO addresult()
	{
		
		int empno = Integer.parseInt(request.getParameter("empno"));
		String ename = request.getParameter("ename");
		String hiredate = request.getParameter("hiredate");
		int sal = Integer.parseInt(request.getParameter("sal"));
		EmpVO ev = new EmpVO(empno,ename,hiredate,sal);
		ev.setEmpno(empno);
		ev.setEname(ename);
		ev.setHiredate(hiredate);
		ev.setSal(sal);
		return ev;
	}
}
