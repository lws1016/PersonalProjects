package com.ezen.spring.empfile;

import java.io.Serializable;
import java.util.Objects;

import org.springframework.stereotype.Component;
@Component
public class EmpVO implements Serializable 
{
	
	private int empno;
	private String ename;
	private String hiredate;
	private int sal;
	
	public EmpVO(){}

	public EmpVO(int empno, String ename, String hiredate, int sal) {
		super();
		this.empno = empno;
		this.ename = ename;
		this.hiredate = hiredate;
		this.sal = sal;
	}
	
	
	
	@Override
	public int hashCode() {
		return Objects.hash(empno, ename);
	}

	@Override
	public boolean equals(Object obj) {
		EmpVO other = (EmpVO) obj;
		return this.empno == other.empno || Objects.equals(ename, other.ename);
	}

	@Override
	public String toString() {
		return String.format("%d %s %s %d",empno,ename,hiredate,sal);
	}

	public int getEmpno() {
		return empno;
	}

	public void setEmpno(int empno) {
		this.empno = empno;
	}

	public String getEname() {
		return ename;
	}

	public void setEname(String ename) {
		this.ename = ename;
	}

	public String getHiredate() {
		return hiredate;
	}

	public void setHiredate(String hiredate) {
		this.hiredate = hiredate;
	}

	public int getSal() {
		return sal;
	}

	public void setSal(int sal) {
		this.sal = sal;
	}
	
	

}
