package com.ezen.spring.form;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

@Controller //응답이 JSON으로만 하고 싶을때
@RequestMapping("/form")//url을 이것으로 할때 씀
public class FormController 
{
	static String fpath = "D:/test/member.ser";
	@Autowired // new 선언을 안해도 파라미터에 클래스 변수선언만 해주면 new 클래스();한 효과와 같아짐
	FormSvc fs;
	@GetMapping("/")//get방식 요청
	@ResponseBody
	public String index()
	{
		return "Hello";
	}
	
	@GetMapping("/login")
	public String login()
	{
		return "login/loginForm";
	}
	@PostMapping("/login")//post방식 요청
	@ResponseBody //이메소드를 결과값을 출력하는 용도로만 쓰겟다고 선언한것 1메소드 1ResponseBody를 해줘야함 json방식으로 할때 유용함
	public Map<String,Boolean> loginproc(User user)
	{
		Map<String, Boolean> map = new HashMap<>();
		map.put("login", fs.login(user));
		return map;
	}
	
}
