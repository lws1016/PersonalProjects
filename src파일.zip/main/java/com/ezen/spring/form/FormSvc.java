package com.ezen.spring.form;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class FormSvc {
	
	public boolean login(User user)
	{
		String id = user.getId();
		String pwd = user.getPwd();
		//boolean login = dao.login(user); dao를 이용한다면 이렇게 쓸수도 있음 
		//return login;
		return id.equals("smith") && pwd.equals("1234");
	}
}
