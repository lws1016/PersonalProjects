package com.ezen.spring.form;

import org.springframework.stereotype.Component;

@Component //MVC패턴중 하나의 부품으로 취급한다
public class User {
	private String id;
	private String pwd;
	
	public User(){}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPwd() {
		return pwd;
	}

	public void setPwd(String pwd) {
		this.pwd = pwd;
	};

	
}
