package com.ezen.spring.soccer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/foot")
public class SoccerController {
	
	@GetMapping("/")
	public String index()
	{
		return "foot/index";
	}
	
	@GetMapping("/add")
	public String add()
	{
		return "foot/add";
	}

	@GetMapping("/edit")
	public String edit()
	{
		return "foot/edit";
	}
	
	  	@PostMapping("/add")
	    public List<Soccer> add2(@RequestBody Soccer newPlayer) {
	        List<Soccer> result = new ArrayList<>();
	        Map<String,Object> result2 = new HashMap<>();
	        try {
				// TODO: 여기서는 간단히 리스트에 선수를 추가하는 로직을 구현했습니다.
	            // 실제로는 데이터베이스에 저장하는 등의 로직이 필요합니다.
	            result.add(newPlayer);

	            result2.put("success", true);
	            result2.put("message", "축구선수가 추가되었습니다.");
	        } catch (Exception e) {
	            result2.put("success", false);
	            result2.put("message", "축구선수 추가에 실패했습니다.");
	        }

	        return result;
	    }
	  	
	  	@PostMapping("/edit")
	  	public Map<String, Object> editPlayer(@RequestBody Soccer modifiedPlayer, Map<String, Object> players) {
	  	    Map<String, Object> result = new HashMap<>();

	  	    try {
	  	        // 기존에 등록된 선수 정보를 수정하는 로직
	  	        int playerIdToEdit = modifiedPlayer.getNum(); // 수정하고자 하는 선수의 ID

	  	        for (int i = 0; i < players.size(); i++) {
	  	            Object player = players.get(i);
	  	            if (((Soccer) player).getNum() == playerIdToEdit) {
	  	                // 기존에 등록된 선수 정보를 수정합니다.
	  	                //((Object) players).set(i, modifiedPlayer);

	  	                result.put("success", true);
	  	                result.put("message", "축구선수 정보가 수정되었습니다.");
	  	                return result; // 수정 성공 시 메소드 종료
	  	            }
	  	        }

	  	        // 수정하고자 하는 ID를 가진 선수가 리스트에 없을 경우
	  	        result.put("success", false);
	  	        result.put("message", "해당 ID를 가진 축구선수를 찾을 수 없습니다.");
	  	    } catch (Exception e) {
	  	        result.put("success", true);
	  	        result.put("message", "축구선수 정보 수정완료");
	  	    }

	  	    return result;
	  	}

}