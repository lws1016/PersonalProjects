package com.ezen.spring.soccer;

public class SoccerDAO {
	
	
}
