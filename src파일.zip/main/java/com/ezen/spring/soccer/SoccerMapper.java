package com.ezen.spring.soccer;

public interface SoccerMapper {

}
