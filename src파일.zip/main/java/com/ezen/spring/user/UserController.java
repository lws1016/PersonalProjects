package com.ezen.spring.user;

import java.util.*;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.oracle.wls.shaded.org.apache.xalan.lib.Redirect;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Controller 
@RequestMapping("/user")
@SessionAttributes("userid")
public class UserController {
	@Autowired
	UserSVC userSvc;
	@GetMapping("/login")
	public String logincheck()
	{
			return "emp/loginForm";
	}
	@PostMapping("/login")
	@ResponseBody
	public Map<String, Boolean> logincheck(@Qualifier("usr")UserVO user,Model model)
	{
		boolean login = userSvc.login(user);
		if(login)
		{
			model.addAttribute("userid",user.getUid());
			System.out.println(user.getUid());
			
		}
		Map<String, Boolean> map = new HashMap<>();
		map.put("added", login);
		return map;
		
	}
	@PostMapping("/logout")
	@ResponseBody
	public Map<String,Object> logout(SessionStatus status)
	{
		Map<String, Object> map = new HashMap<>();
		status.setComplete();
		map.put("logout", true);
		return map;
	}

	
}
