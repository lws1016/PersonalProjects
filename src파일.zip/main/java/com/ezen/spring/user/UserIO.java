package com.ezen.spring.user;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
@Service
@Component
public class UserIO {
	static String fpath = "D:/test/emp.txt";
	
	public boolean login(UserVO user) {
	    BufferedReader reader = null;
	    List<UserVO> blist = new ArrayList<>();
	    try {
	        reader = new BufferedReader(new FileReader(fpath));
	        String line =null;
	        while ((line = reader.readLine()) != null) {
	        	UserVO vo = new UserVO(line);
	            if (vo.equals(user)) {
	            	reader.close();
	            	return true;
	            }
	        }
	        reader.close();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
	    return false;
	}

}
