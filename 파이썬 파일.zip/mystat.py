def avg(score):
    total = 0
    for s in score:
        total += s
    return total / len(score)

def sum(score):
    total = 0
    for s in score:
        total += s
    return total 
        
